<?php

namespace App\WebPage\Types;

enum HtmlParserType: string
{
  case PHP_HTML_PARSER = 'PHPHtmlParser';
}
