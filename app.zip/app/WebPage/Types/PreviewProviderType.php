<?php

namespace App\WebPage\Types;

enum PreviewProviderType: string
{
  case MICROWEBER = 'Microweber';
}
