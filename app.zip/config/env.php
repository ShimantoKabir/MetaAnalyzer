<?php
return [
    "htmlParserType" => env("HTML_PARSER_TYPE"),
    "previewProviderType" => env("PREVIEW_PROVIDER_TYPE"),
    "envType" => env("APP_ENV")
];
